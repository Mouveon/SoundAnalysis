var mongoose = require('mongoose');
var bcrypt = require('bcryptjs');

// Schema utilisateur
var UserSchema = mongoose.Schema({
	pseudo: {
		type: String,
		index:true
	},
	pass: {
		type: String
	},
	niveau: {
		type: String
	},
	prout: {
		type: String
	}
},{strict: false});

var User = module.exports = mongoose.model('Utilisateurs', UserSchema);

module.exports.createUser = function(newUser, callback){
	bcrypt.genSalt(10, function(err, salt) {
	    bcrypt.hash(newUser.pass, salt, function(err, hash) {
	        newUser.pass = hash;
	        newUser.save(callback);
	    });
	});
}

module.exports.getUserByUsername = function(pseudo, callback){
	var query = {pseudo: pseudo};
	User.findOne(query, callback);
}

module.exports.getAdmin = function(callback){
	var admin = 'A';
	var query = {niveau: admin};
	User.findOne(query, callback);
}

module.exports.getUserById = function(id, callback){
	User.findById(id, callback).lean();
}	

module.exports.getUsers = function(callback){
	var query = {$or : [{niveau: "A"}, {niveau: "U"}]};
	User.find(query, callback);
	console.log(query);
}

module.exports.getUserByLvl = function(niveau, callback){
	var query = {niveau: niveau};
	User.find(query, callback);
	console.log(query);
}

module.exports.comparePassword = function(candidatPass, hash, callback){
	bcrypt.compare(candidatPass, hash, function(err, isMatch) {
    	if(err) throw err;
    	callback(null, isMatch);
	});
}

module.exports.getAllUser = function(callback) {
	User.find({},callback);
}

module.exports.deleteUser = function(id, callback) {
	User.findByIdAndRemove(id,callback);
}

module.exports.update = function (id, modif,valeur, callback) {

	var query = {};

	var pass="pass";
	var pseudo="pseudo";
	var niveau="niveau";
	var autorisation="prout";

	  if(modif[0]==true) {
		query[pass] = valeur[0];};
	  if(modif[1]==true) {
		query[pseudo] = valeur[1];}
	  if(modif[2]==true) {
		query[niveau] = valeur[2];}
	  if(modif[3]==true) {
		query[autorisation] = valeur[3];}
	    
	User.findOneAndUpdate({"_id":id}, query, callback);

}
