var mongoose = require('mongoose');

// Schema des infos
var InfoSchema = mongoose.Schema({
	Idgr: {
		type: String,
		index:true
	},
	sonometre: {
		type: String
	},
	micro: {
		type: String
	},
	user: {
		type: String
	},
	sensibilite: {
		type: String
	},
	type: {
		type: String
	}
},{strict: false});

var Info = module.exports = mongoose.model('Info',InfoSchema,'Acquisitions');

// Schema des data
var DataSchema = mongoose.Schema({
	cnt: {
		type: String
	},
	leq: {
		type: String
	},
	la: {
		type: String
	},
	lc: {
		type: String
	},
	dt: {
		type: String
	},
	Idgr: {
		type: String,
		index:true
	}
},{strict: false});

var Data = module.exports = mongoose.model('Data',DataSchema,'Acquisitions');

module.exports.createInfo = function(newInfo, callback){
//	        Info.create(newInfo);
                var newI = Info(newInfo);
		newI.save(function(err){
		  if(err) console.log(err);
		});
}

module.exports.createData = function(newData, callback){
//	        Data.create(newData);
                var newD = Data(newData);
		newD.save(function(err){
		  if(err) console.log(err);
		});
}
