var mongoose=require('mongoose');

mongoose.connect('mongodb://localhost/raspiquenique');
var db = mongoose.connection;

var User = require('./utilisateur');

console.log('Bonjour');

User.getUserByUsername("Pierre", function(err,user){
console.log(user);
});

User.update("59401d1aebf83043d6ac17b9",{nom: "Essai"}, function(err,doc){
console.log(doc);
});
/*
// Schema utilisateur
var UserSchema = mongoose.Schema({
        pseudo: {
                type: String,
                index:true
        },
        pass: {
                type: String
        },
        niveau: {
                type: String
        },
        nom: {
                type: String       

        }
});

var User = module.exports = mongoose.model('Utilisateurs', UserSchema);


User.find({}, function(err,users){
	console.log(users);
});


User.findByIdAndRemove('593ea5cc95b5b32bbee40ca9', function (err){
console.log('ok');
});


User.findOneAndUpdate({_id: "59401d1aebf83043d6ac17b9"},{nom: "Testeuse moisie"}, function (err){
 console.log('ok');
});
*/
