var r = require('./.variable');

var arr = [];
var i = 0;
var a = 63;

arr.push([i,'./Systeme']);
i++;
arr.push([i,'./Audio']);
i++;
arr.push([i,'./Sonom']);
i++;

//console.log(arr);
console.log(r.modele);
console.log(r.binaire(10));
