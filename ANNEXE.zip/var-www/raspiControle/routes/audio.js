var express = require('express');
var router = express.Router();
var AudioPlayer = require('sox-play');
var fs=require('fs'); 
var mod=require('../.variable');
var spawn = require('child_process').spawn;
var multer = require('multer');


var storage = multer.diskStorage({
  destination: function(req,file,callback){
    callback(null,'/var/www/raspiControle/public/song/');
  },
  filename: function(req,file,callback){
    console.log(file);
    callback(null,file.originalname)
  }
});


var upload = multer({storage: storage}).array('file',5);

//var lazy = require('lazy');
//var soundengine = require("soundengine");

var player = new AudioPlayer();
var flag_play = 0;
var audio = 0;

/* Foncion de lecture ligne par ligne de fichier
function readLines(input, func){
  var remaining = '';

  input.on('data',function(data){
    remaining += data;
    var index = remaining.indexOf('\n');
    var last = 0;
    while(index > -1) {
      var line = remaining.substring(last,index);
      last = index +1;
      func.push(line);
      console.log(func+'lili');
      index = remaining.indexOf('\n');
    }
    remaining = remaining.substring(last);
  });

  input.on('end', function(){
    if(remaining.length > 0) {
      func.push(remaining);
      console.log(func);
    }
  });
}
*/


//Middleware de verif d'autorisations
var group_audio = function() {
  return function(req,res,next){
	if(typeof req.user == 'undefined'){
	res.send(401, "AUTHENTIFICATION RECQUISE");
	}
	else if((req.user.prout & mod.bin_Audio) != 0) 
	  next();
	else 
	  res.send(401, "T'AS TENTE L'AUDIO ON T'A VU");
   // if(req.user.prout == );
  };
};
// Page d'acceuil /!\ J'ai oublié d'implémenter un middleware d'autorisation
router.get('/', group_audio(), function(req, res){

	var donnee = [];

	console.log("Page d'audio ");
	//Affichage des messages et enregistrement de la page dans le cookie
	res.locals.message = req.flash('message');
	req.session.lastPage=req.originalUrl;
	//Listes des fichiers sons
	fs.readdir('/var/www/raspiControle/public/song',function(err,items){
   	  console.log("sons récupérés: "+items);
//	  fs.readFile('/proc/asound/pcm',function(err,donnee);
	//Liste des cartes sonores actives
	  var donnee_tmp = fs.readFileSync('/proc/asound/cards').toString().split('\n');
//	  var periph = fs.readFileSync('/proc/asound/pcm').toString().split('\n');
	  //readLines(input,donnee);
	  for(var i = 0; i<donnee_tmp.length; i++){
 	    if (i%2 == 0) {
	      donnee.push(donnee_tmp[i]);   
	    }
	  }
	  console.log(donnee);
	  donnee.pop();
//	  periph.pop();
          
	  console.log(donnee);
//	  console.log(periph);
//	  console.log("hw:"+donnee[0][0]+donnee[0][1]+","+donnee[0][3]+donnee[0][4]);
	    //var audio = soundengine.getDevices();
	    //audio.splice(audio.indexOf("sysdefault"),1);
	    //audio.splice(audio.indexOf("default"),1);
	    //audio.splice(audio.indexOf("dmix"),1);
	    res.render('audio',{sons: items, devices: donnee});
//            });
	});
	
});

//L'ajaxUUU
router.post('/test', group_audio(), function(req,res){
	var temps;
	console.log("Demande du player");
	console.log("Donnée envoyé"+JSON.stringify(req.body));
        console.log("Play?Stop?: "+req.body.joue);

	audio = req.body.audio;
	console.log("Son: "+audio);
	//Si play est appuyé
	if(req.body.joue == 1){
	  console.log("Lecture d'un fichier");
	    if(typeof req.body.mute == "undefined"){
	      console.log("Il faut unmute avant de jour");
	      spawn('amixer',['set','PCM','unmute']);    	        
	    }           
	    //Si un son est en cours de lecture
	    if (flag_play == 1) {
	      console.log("Arret du son deja en lecture");
  	      //Si la repetition est activé
	      if(req.body.repete == 1) {
  	        console.log("Repetition activé");
                player.stop();
	        player.on('stop', function(filePath){
  	          player= AudioPlayer({file:'/var/www/raspiControle/public/song/'+req.body.son},audio);
            	  player.replay();
	          flag_play = 1;
/*	
		  player.on('stop', function(filePath){
		    console.log("le replay doit se lancer");
		    //FAIRE UN SET TIME OUT 
		    setTimeout(function(){
		      console.log("CA REPLAY");
		      player = AudioPlayer({file:'/var/www/raspiControle/public/song/'+req.body.son},audio);
		      player.replay();
		    },temps*1000);
		  });
*/
	        });
	      } else if(req.body.repete ==0){
  	          console.log("ARRET DU SON");
                  player.stop();
	          player.on('stop', function(filePath){
  	          player= AudioPlayer({file:'/var/www/raspiControle/public/song/'+req.body.son},audio);
            	  player.play();
	          flag_play = 1;	
		  player.on('stop', function(filePath){
		    flag_play=0; 
		  });
	        });
	      }
	    }//Si aucun son n'est en queue
	    else if (flag_play == 0){
	      console.log("Aucun son en queue");
	      //Si repetition activé
	      if(req.body.repete == 1){
		console.log("Repetition active");
	        console.log("valeur de flag"+flag_play);
                player = AudioPlayer({file:'/var/www/raspiControle/public/song/'+req.body.son},audio);
	        console.log("AVOIR"+player.file);
	        player.replay();
	        flag_play = 1;
/*
	        player.on('stop', function(filePath){
		  setTimeout(function(){
		    console.log("CA REPLAY");
		    player = AudioPlayer({file:'/var/www/raspiControle/public/song/'+req.body.son},audio);
		    player.replay();
	          },temps*1000);
	          player= AudioPlayer({file:'/var/www/raspiControle/public/song/test.mp3'},audio);
	          console.log("Ca a stop"+player.file);
	          console.log('Nouveau son'+player.file);
	          player.play();
	        });
*/
 	      } else if(req.body.repete == 0){
		console.log("Päs de répétition");
	        console.log("valeur de flag"+flag_play);
                player = AudioPlayer({file:'/var/www/raspiControle/public/song/'+req.body.son},audio);
	        player.play();
	        flag_play = 1;
	        player.on('stop', function(filePath){
		  flag_play = 0;
/*
	          player= AudioPlayer({file:'/var/www/raspiControle/public/song/test.mp3'},audio);
	          console.log("Ca a stop"+player.file);
	          console.log('Nouveau son'+player.file);
	          player.play();
*/
	        });
	      }
	    }
	}//Si Stop
          else if(req.body.joue == 0) {
	    console.log("Stop lancé");
	    player.stop();
            player.on('stop', function(filePath){
              flag_play=0;
	    });
          }
	else if(req.body.mute) {
	  console.log("on va mute"+req.body.mute);
	  if(req.body.mute == 1)
	    spawn('amixer',['set','PCM','mute']);
	  else 
	    spawn('amixer',['set','PCM','unmute']);
 	}
	else if(req.body.type) {
	  console.log("on va changer le vol avec des db"+req.body.volume);
	  spawn('amixer',['set','PCM','--',100*req.body.volume+'db']);
 	}
	else if(req.body.volume) {
	  spawn('amixer',['set','PCM','--',100*req.body.volume+'db']);
	  console.log("on va changer le volume"+req.body.volume)
//	  soundengine.setVolume({volume: 0});
 	}
 	res.send('ok');
/* DE LA MERDE CE MODULE LA
	var playlist = groove.createPlaylist();
	var player = groove.createPlayer();

	groove.open("/var/www/raspiControle/public/song/test.mp3", function(err,file){
	  if(err) throw err;

	  playlist.insert(file,null);

	  player.attach(playlist, function(err){ 
	    if(err) {
		console.log("erreur"+err);
		throw err;
	    }
	  });

	  console.log("L'appareil est: "+groove.getDevices());
	  console.log("durée:", file.duration());

	  file.close(function(err){
	    if(err) throw err;
	  });
	});
*/
});

//L'ajaxUUU
router.post('/fichier', group_audio(), function(req,res){ 
  upload(req,res,function(err){
    if(err){
      console.log("Erruer"+err);
      return;
    }
    console.log(req.files);
    console.log('Machin upload');
    res.end('fichiers upload');

  })
});

//L'ajaxUUU
router.post('/supprimer', group_audio(), function(req,res){ 
    console.log(req.body);
    fs.unlink('/var/www/raspiControle/public/song/'+req.body.fichier,(err) => {
      if(err) throw err;
//      res.redirect('/');
	res.end('FICHIER SUPPRI');
    });
});
module.exports = router;
