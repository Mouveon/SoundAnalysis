var express = require('express');
var router = express.Router();
var fs = require('fs');
var sleep = require('sleep');
var serialport = require('serialport');
var SerialPort = serialport.SerialPort;
var mod = require('../.variable');

var acquisitions = require('../models/acquisition');

var compSono;


var group_Sonometre = function () {
  return function(req,res,next){
    if(typeof req.user == 'undefined'){
      res.send(401, "AUTHENTIFICATION RECQUISE");
    }
    else if((req.user.prout & mod.bin_Sonometre) != 0)
      next();
    else
      res.send(401, "T'AS TENTE LA SONOMETRIE");
  };
};

// Page d'acceuil
router.get('/', group_Sonometre(), function(req, res){
	var count = 0;

        var actif={};

	req.session.lastPage=req.originalUrl;


        compSono = new serialport('/dev/sonom',{
	  parser: serialport.parsers.readline('\n')
	  },function(err){
	  if(err){
	    actif.etat = 0;
	    res.render('sonometre',{data: actif}); 
	  }
	});

	compSono.on("open", function(){
          compSono.write('*IDN?\n');
	  compSono.write('CALIbrate:MIC:TYPE?\n');
	});


        compSono.on("data", function(data){
          console.log('Data: '+data+" count: "+count);
	  if(count==0){
            console.log("Premiere lecture");
	    actif.data = data;
	  //req.flash('success_msg', actif.data);
	    count++;
          }
	  else{
            console.log("Seconde lecture");
	    actif.etat = 1;
	    actif.micro = data;
	    res.render('sonometre',{data: actif});
            compSono.close();
	  }
        });
/*

	compSono.on("error", function(err){
 	  //console.log('Erre_r: '+err);
	  res.render('sonometre',{data: "0"});
	  compSono.close();
	});
*/
//	res.send("Ok");
	
});

router.get('/test', group_Sonometre(), function(req, res){
  var buffer = new Buffer(5)
    buffer[0] =0x08;
    buffer[1] =0x20;
    buffer[2] =0x00;
    buffer[3] =0x00;
    buffer[4] =0x0A;



  var comp = new SerialPort('/dev/lebel',{
	baudrate: 9600,
	databits: 8,
	parity: 'none'
  });

  comp.on("data", function(data){
    console.log('Data: '+data);
  });
  comp.on("open", function(){
  console.log("ouverte madafucka");
  comp.write('H', function(err){
    console.log('On ecrit H');
    setTimeout(function(){
      comp.write('3',function(err){
	console.log('On ecrit 3');
        setTimeout(function(){
           //comp.write('0x080x200x000x000x0A\n', function(err){});           

           comp.write('0', function(err){
             setTimeout(function(){
	     console.log('le sleep a marché');
             comp.write('x', function(err){
               setTimeout(function(){
               comp.write('0', function(err){
                 setTimeout(function(){
                 comp.write('8', function(err){
                   setTimeout(function(){  
                   comp.write('0', function(err){
                     setTimeout(function(){
         	     comp.write('x', function(err){
                       setTimeout(function(){
                       comp.write('2', function(err){
                         setTimeout(function(){
                         comp.write('0', function(err){
                           setTimeout(function(){
	                   comp.write('0', function(err){
                             setTimeout(function(){
	                     comp.write('x', function(err){
    	                       setTimeout(function(){
                               comp.write('0', function(err){
                                 setTimeout(function(){
                                 comp.write('0', function(err){
                                   setTimeout(function(){
                                   comp.write('0', function(err){
                                     setTimeout(function(){
                                     comp.write('x', function(err){
                                       setTimeout(function(){
           			       comp.write('0', function(err){
                                         setTimeout(function(){       
          			         comp.write('0', function(err){
                                           setTimeout(function(){
           			           comp.write('0', function(err){
                                             setTimeout(function(){
           			             comp.write('x', function(err){
                                               setTimeout(function(){
           			               comp.write('0', function(err){
                                                 setTimeout(function(){
           			                 comp.write('A', function(err){
                                                   setTimeout(function(){
           			                   comp.write('\r', function(err){
                                                   });
						   },490);
	   					 });
	   				         },480);
					       });
					       },480);
	   				     });
					     },470);
	   				   });
					   },460);
	   				 });
					 },450);
	   			       });
				       },440);
	   			     });
				     },430);
	   			   });
				   },420);
				 });
				 },410);
	   		       });
			       },400);
		             });
			     },390);
	                   });
			   },380);
			 });
			 },370);
		       });
		       },360);	               
		     });
		     },350);	   	     
		   });
		   },340);
	         });
		 },330);
	       });
	       },320);
	     });
	     },310);
    	   });
        },300);
      });
    },100);
    });
  });
});


/*

com.open(function(error){
	if(error){
	  console.log('bin voilla');
	} else {
	         console.log('port ouver');
	         com.write('h');

	var st = fs.createWriteStream('/dev/ttyACM0');
        st.write('h');
	setTimeout(function(){
	  st.write('3');
	  setTimeout(function(){
	    var buffer = new Buffer(5);
	    st.write('0x080x200x000x000x0A\n');
	    st.end();},300);
	},100);

});
*/

router.post('/com', group_Sonometre(), function(req, res){
  var recup = req.body.commande
  console.log("Commande sonometre "+recup);

//  var ReadLine = serialport.parsers.ReadLine;
  var comp = new serialport('/dev/sonom',{
    parser: serialport.parsers.readline('\n')
  });


  if(recup.indexOf('?') != -1){
    comp.on("open", function(){
      console.log("ouverte madafucka");
      comp.write(recup+'\n');
    });

    comp.on("data", function(data){
      console.log('Data: '+data);
      res.send(data);
      comp.close();
    });
  }else{
    comp.on("open", function(){
      console.log("ouverte madafucka");
      comp.write(recup+'\n');
      res.send("COMMANDE ENVOYE");
      comp.close();
    });
  }
  //comp.write('*IDN?\n');
});

router.post('/acquisition', group_Sonometre(), function(req, res){
//  var ReadLine = serialport.parsers.ReadLine;
  console.log('REQUETE '+JSON.stringify(req.body));

  var demande = req.body.st;

  var dataInfo={}; 

  dataInfo.Idgr=req.body.Idgr;
  dataInfo.sonometre=req.body.sono;
  dataInfo.micro=req.body.mic;
  dataInfo.user=req.user.pseudo;

  var flag_acq=0;
  var Idgr = req.body.Idgr;
/*  var sonometre = req.body.sono;
  var micro = req.body.mic;
  var sensibilite;
  var type;
*/
  var dataSess={};


  var f=0;

/*
  var routine = function(){

    setTimeout(function(){
      console.log("ACQUISITION EN COURS");
    },1000);
    f++;
*/
//	  setTimeout(function(){
//	    console.log("Acquisition en cours");
//  	    compAcq.write('MEAS:INIT\n');
//	    compAcq.write('MEAS:SLM:RTA:DT? EQ\n');
//	    compAcq.write('MEAS:DTTI?\n');
//  	  },1000);
//  };
/*
do{
  setTimeout(function(){
    console.log("ACQUISITION EN COURS");
  },1000);
  f++;
}while(f!=30);  
*/

  console.log("demande: "+demande);

  if(demande == 1){

    var count=0;

    global.compAcq = new serialport('/dev/sonom',{
      parser: serialport.parsers.readline('\n')
    });

    compAcq.on("data", function(data){
      if(count == 0){
        console.log('Sensib mic: '+data);
        dataInfo.sensibilite=data.trim();
	count++;
      }else if(count == 1){
        console.log('Type mic: '+data);
	dataInfo.type=data.trim();
	acquisitions.createInfo(dataInfo);
        console.log(dataInfo);
	count++;
      }else if(count == 5){
	//VALUE OF DT
//        console.log('DT: '+data);
	dataSess.dt=data.trim();
	dataSess.Idgr=Idgr;
	console.log(dataSess);
	acquisitions.createData(dataSess);
        count=2;
      }else if(count == 2){
	//LEQ SPECTRAL
//        console.log('LEQ: '+data);
	dataSess.cnt=String(Date.now());
	dataSess.leq=data.trim();
        count++;
      }else if(count == 3){
	//LA
//        console.log('LA: '+data);
	dataSess.la=data.trim();
        count++;
      }else if(count == 4){
	//LC
//        console.log('LC: '+data);
	dataSess.lc=data.trim();
        count++;
      }
    });

    compAcq.on("open", function(){ 

      console.log(flag_acq);
      console.log("ouverte");
      compAcq.write('CALIbrate:MIC:SENS:VALUE?\n');
      compAcq.write('CALIbrate:MIC:SENS:SOURCE?\n');
      compAcq.write('INIT START\n');
      compAcq.write('INIT START\n');
      setTimeout(function(){
	console.log(flag_acq);
	console.log("Test primer sleep");
	if(flag_acq <1) console.log("Test condition");
//	do{
	    global.routine = setInterval(function(){
	      console.log("Acquisition en cours");
  	      compAcq.write('MEAS:INIT\n');
	      compAcq.write('MEAS:SLM:RTA:DT? EQ\n');
	      compAcq.write('MEAS:SLM:123:dt? LAEQ\n');
	      compAcq.write('MEAS:SLM:123:dt? LCEQ\n');
	      compAcq.write('MEAS:DTTI?\n');
          },1000);
//	}while(flag_acq < 1);
	console.log("normalement il passe pas la");
	res.end();
      },3000);
    });
  //S'il s'agit d'un arrêt des mesures
  }else if(demande == 0){
    console.log("ATTENTION");
    if(typeof compAcq != 'undefined') {
      clearInterval(routine);
      setTimeout(function(){
        compAcq.write('INIT STOP\n');
        compAcq.close();
        res.end();
       },200);
    }else res.end();
  }

console.log(req.body.st);
/*
  var comp = new serialport('/dev/sonom',{
    parser: serialport.parsers.readline('\n')
  });


  if(recup.indexOf('?') != -1){
    comp.on("open", function(){
      console.log("ouverte madafucka");
      comp.write(recup+'\n');
    });

    comp.on("data", function(data){
      console.log('Data: '+data);
      res.send(data);
      comp.close();
    });
  }else{
    comp.on("open", function(){
      console.log("ouverte madafucka");
      comp.write(recup+'\n');
      res.send("OK");
      comp.close();
    });
  }
  //comp.write('*IDN?\n');

*/

});

module.exports = router;
