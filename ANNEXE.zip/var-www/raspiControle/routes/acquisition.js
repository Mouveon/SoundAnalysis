var express = require('express');
var router = express.Router();
var mod = require('../.variable');

var group_Acquisition = function () {
  return function(req,res,next){
    if(typeof req.user == 'undefined'){
      res.send(401,"AUTHENTIFICATION RECQUISE");	
    }
    else if((req.user.prout & mod.bin_Acquisition) != 0)
      next();
    else
      res.send(401, "FAUX");
  }
};

// Page d'acceuil
router.get('/', group_Acquisition(), function(req, res){
	res.locals.message = req.flash('message');
	req.session.lastPage = req.originalUrl;
	res.render('acquisition');
	
});


module.exports = router;
