var express = require('express');
var router = express.Router();
var passport = require('passport');
var LocalStrategy = require('passport-local').Strategy;

var User = require('../models/utilisateur');
var mod = require('../.variable');

/*
var session = function (req,res) {
 console.log("La!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! session est elle renouvellé?");
  var temp = req.session.passport;
  req.session.regenerate(function(err){
    req.session.passport = temp;
    res.redirect('/');
  });
};
*/

passport.use(new LocalStrategy({
  usernameField: 'pseudo',
  passwordField: 'pass',
  passReqToCallback: true},
  function(req, pseudo, pass, done) {
      User.getUserByUsername(pseudo, function(err, user){
       	if(err) {
	  console.log("Erreur à l'authentification");
          throw err;
	}
   	if(!user){
	  req.flash('nomUtilisateur', req.body.pseudo);
	  req.flash('message','T\'existes absolument pas');
   	  return done(null, false, {nomUtilisateur: 'reesaye'});
   	}
      User.comparePassword(pass, user.pass, function(err, isMatch){
   	if(err) throw err;
   	if(isMatch){
//Si 0 cookie
	  console.log("User bien autentifié");
	  if(!req.session.user){
	    console.log("Creation d'un cookie");
	    req.session.user = user._id;
	    return done(null,user);
	  }
//S'il y'a deja un cookie et que c'est le bon
	  else if(req.session.user == user._id){
	    console.log("Recup du cookie");
   	    return done(null, user);
  	  }
	  else{
//S'il y'a deja un cookie mais que c'est pas le bon
	    console.log("SUPPRESION du cookie");
            var temp = req.session.passport;
	    req.session.regenerate(function(err){
	      req.session.passport = temp;
	      req.session.user = user._id;
	      return done(null,user);
	    });
	  }
   	} else {
	                req.flash('nomUtilisateur', req.body.pseudo);
			req.flash('message','Mot de passe érroné');
   			return done(null, false, {nomUtilisateur: 'reesaye'});
   		}
	});
   });
  }));

passport.serializeUser(function(user, done) {
  done(null, user.id);
});

passport.deserializeUser(function(id, done) {
  User.getUserById(id, function(err, user) {

  var auto = new Array();
  var modele = mod.modele;
  var tab = mod.binaire(user.prout);
  
  for(var i=0; i < modele.length; i++){
    if(tab[i]==1) auto.push(modele[i].replace("_"," "));
    else auto.push('0');
  }
    user.affiche = auto;
    return done(err, user);
  });
});

//Middleware de verification de type d'utilisateur
var group = function() {
  return function(req, res, next) {
    if(typeof req.user == 'undefined'){
      res.send(401,'AUTHENTIFICATION RECQUISE');
    }else if (req.user && (req.user.niveau == 'S' || req.user.niveau == 'A'))
      next();
    else
      res.send(401, 'TENTATIVE DE HACK DU MODULE UTILISATEUR');
    };
};  

// Page d'utilisateur
router.get('/connexion', function(req, res, nom){
        res.locals.nomUtilisateur = req.flash('nomUtilisateur');
	res.locals.message = req.flash('message');
	res.locals.error = req.flash('error');
	res.render('connexion');
});

router.get('/deconnexion', function(req, res){
	req.logout();
	req.flash('success_msg', 'Vous êtes déconnecté');
	console.log(req.url+" EVERITHING SHE SAID");
	res.redirect('/utilisateurs/connexion');
});

// Page de gestion
router.get('/gestion', group(), function(req, res){
	console.log("Page de gestion des sessions");
	console.log(req.session);
	res.locals.message = req.flash('message');
	if(req.user.niveau == 'S'){
	  console.log("SuperAdmin reconnu");
	  User.getUserByLvl('A', function(err,liste) {
	    res.render('gestionUtilisateur', {listes: liste});
	  });
	}else if(req.user.niveau =='A'){
	  console.log("Admin reconnu");
	  User.getUsers(function(err,liste) {
	    res.render('gestionUtilisateur', {listes: liste});
	    console.log("LKEIODJDI"+liste);
	  });
	} else{
            res.send(401, 'Tu es arrivé bien loin petit hackeur');
	}
});

// Page d'enregistrement
router.get('/gestion/enregistrer', group(), function(req, res){
	req.session.lastPage = req.originalUrl;
	res.render('enregistrement');
});

// Methode d'enregistrement
router.post('/gestion/enregistrer', group(), function(req, res){
	var username = req.body.username;
	var password = req.body.password;
	var password2 = req.body.password2;
	var level = req.body.level;
	
	// Validation
	req.checkBody('username', 'Il faut un pseudo').notEmpty();
	req.checkBody('password', 'Il faut un mot de passe').notEmpty();
	req.checkBody('password2', 'Relis toi crétin').equals(req.body.password);
	req.checkBody('level', 'Relis toi crétin').notEmpty();
	req.checkBody('autorisation','il faut un truc au moins').notEmpty();

	var errors = req.validationErrors();

	if(errors){
		res.render('enregistrement',{
			errors:errors
		});
	} else {
		var autorisations =0;
		console.log(req.body.autorisation);	
		for(var j=0; j<req.body.autorisation.length; j++){
	  	  autorisations+=Math.pow(2,req.body.autorisation[j]);
	        };
   

		var newUser = new User({
			pseudo: username,
			pass: password,
			niveau: level,
			prout: autorisations.toString()
		});
		User.createUser(newUser, function(err, user){
			if(err) throw err;
			console.log("Création du nouvel utilisateur: "+user);

		req.flash('success_msg', 'Vous êtes enregistré maintenant');
		res.redirect('/utilisateurs/gestion');
		});

	}

});


//Supprression d'user
router.get('/gestion/supprimer/:id', group(), function (req, res) {
  req.session.lastPage = req.originalUrl;
  console.log("Suppression de l'utilisateur: "+id);
  var id = req.params.id;
  User.deleteUser(id,function (err){});
  req.flash('message','Utilisateur efface');
  res.redirect('/utilisateurs/gestion');
});

//Gestion d'user
router.get('/gestion/:id', group(), function (req, res) {

  req.session.lastPage = req.originalUrl;

  var id = req.params.id;

  User.getUserById(id, function(err, utilisateur) {
 
  var auto = req.user.affiche;
/*
  var modele = mod.modele;
  var tab = mod.binaire(req.user.prout);
  
  for(var i=0; i < modele.length; i++){
    if(tab[i]==1) auto.push(modele[i].replace("_"," "));
    else auto.push('0');
  }
    console.log("bouahaha :"+auto);
*/
  var tab_bis = mod.binaire(utilisateur.prout);


  for(var x=0; x<tab_bis.length; x++){
    if(tab_bis[x] == 1) auto[x]+='#';
  }

  res.render('modification', {modif: utilisateur, changement: auto});
  });

});

//Methode de connexion
router.post('/connexion',
  passport.authenticate('local', 
    {successRedirect: '/',
    failureRedirect:'/utilisateurs/connexion',
    failureFlash: true})
  );

//Methode de modification
router.post('/gestion/modifier/:id', group(), function(req,res) {
	var username = req.body.username;
	var password = req.body.password;
	var password2 = req.body.password2;
	var level = req.body.level;

/*
	req.checkBody('username','Il faut un pseudo').notEmpty();
	req.checkBody('level','relis toi crétin').notEmpty();
	req.checkBody('autorisation','il faut un truc').notEmpty();
	
	var errors = req.validationErrors();
	if(errors){
		res.render('modification', {
			errors:errors
		});
	}
*/

        var id = req.params.id;
	var champ = new Array(4);
	var modif_pass_nom_pseudo_niveau=[false,false,false,false];
	var flag=false;
	//var modif_debut=false;

if(req.user.niveau == 'A' && req.body.level == 'A'){
}else{
	var autorisations=0;
	for(var z=0; z<req.body.autorisation.length;z++){
		autorisations+=Math.pow(2,req.body.autorisation[z]);
	};
}
	if (password != ''){
	  req.checkBody('password2', 'Mauvaise confirmation').equals(req.body.password);
       	  var errors = req.validationErrors();
	  if(errors){
		res.render('modification',{
			errors:errors
		});
	  } else {
		modif_pass_nom_pseudo_niveau[0]=true;
		champ[0]=password;
		flag = true;
		//query += "\"pass\": \" " + req.body.password +"\"";
		//modif_debut=true; 
	  } 
        }
	//modification dans la BDD
         User.getUserById(id, function(err, user) {
	     console.log(user);
	     if (username != user.pseudo) {
		modif_pass_nom_pseudo_niveau[1]=true;
		champ[1]=username;
		flag=true;}
	     if (level != user.niveau) {
		modif_pass_nom_pseudo_niveau[2]=true;
		champ[2]=level;
		flag=true;}
	     if(req.user.niveau == 'A' && req.body.level == 'A'){
	     }else{
               if (autorisations != user.autorisation) {
	 	  modif_pass_nom_pseudo_niveau[3]=true;
		  champ[3]=autorisations;
		  flag=true;}
	     }
		if (flag == false) {
		res.redirect('/utilisateurs/gestion');}
	      else {
		User.update(id,modif_pass_nom_pseudo_niveau,champ,function(err,doc){
		  req.flash('success_msg', 'Utilisateur modifié');
		  if(req.user.niveau == 'S'){
		    res.redirect('back');
		  } else{
		    res.redirect('/utilisateurs/gestion');
		  }
		});
              }
	  });
});


module.exports = router;
