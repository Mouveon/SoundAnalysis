var express = require('express'); 
var router = express.Router();
var fs = require('fs');
var serialport = require('serialport');
var SerialPort = serialport.SerialPort;
var mod = require('../.variable');

var User = require('../models/utilisateur');

// Page d'acceuil
router.get('/', ensureAuthenticated, function(req, res){
	console.log("Utilisateur connecté: "+req.user);
	console.log("A voir si c'est le bon: "+JSON.stringify(req.sessionID));
	res.locals.message = req.flash('message');
	if (typeof req.session.lastPage != 'undefined'){
	  console.log("Accés à la derniere page"+req.session.lastPage);
	  res.redirect(req.session.lastPage);
	}
	else if (req.user.niveau == 'S'){
	  console.log("SuperAdmin reconnu on envois sa page default");
	  User.getAdmin(function(err,manage) {
//	    res.redirect('/utilisateurs/gestion');
	    res.redirect('/utilisateurs/gestion/'+manage._id); 
	  });
	} else if(req.user.niveau == 'A'){
	  console.log("Admin reconnu on envoit sa page default");
	  res.redirect('/utilisateurs/gestion');
	}else{
	  console.log("Utilisateur reconnu on envoit sa page default");
	  var a = 0;
	  while(req.user.affiche[a] == '0'){
	    a++;
	  }
	console.log("Accés à la page "+req.user.affiche[a]);
	res.redirect('/'+mod.modele[a]);
       }
});

// Page d'acceuil
router.get('/index',ensureAuthenticated, function(req, res){
	console.log("Ancienne page d'acceuil");
	req.session.lastPage = req.originalUrl;
	res.render('index');
});

function ensureAuthenticated(req, res, next){
	console.log("Authentification");
	if(req.isAuthenticated()){
		return next();
	} else {
//		req.flash('error_msg','Vous n'êtes pas enregistré');
		res.redirect('/utilisateurs/connexion');
	}
}


// Page d'acceuil
router.get('/test', function(req, res){
console.log("page de dev general");
var buffer = new Buffer(5)
    buffer[0] = 0x08;
    buffer[1] =0x20;
    buffer[2] =0x00;
    buffer[3] =0x00;
    buffer[4] =0x0A;


console.log("WOUHOU"+serialport);
console.log("Ptet"+serialport.SerialPort);


var comp = new SerialPort('/dev/ttyACM0',{
	baudrate: 9600,
	databits: 8,
	parity: 'none'
});

comp.on("open", function(){
  console.log("ouverte madafucka");
  comp.write('H', function(err){
    setTimeout(function(){
      comp.write('3',function(err){
      });
    },100);
     setTimeout(function(){
       //comp.write('0x080x200x000x000x0A\n', function(err){});
     /*
       comp.write('0', function(err){});
       comp.write('x', function(err){});
       comp.write('0', function(err){});
       comp.write('8', function(err){});
       comp.write('0', function(err){});
       comp.write('x', function(err){});
       comp.write('2', function(err){});
       comp.write('0', function(err){});
       comp.write('0', function(err){});
       comp.write('x', function(err){});
       comp.write('0', function(err){});
       comp.write('0', function(err){});
       comp.write('0', function(err){});
       comp.write('x', function(err){});
       comp.write('0', function(err){});
       comp.write('0', function(err){});
       comp.write('0', function(err){});
       comp.write('x', function(err){});
       comp.write('0', function(err){});
 
     */

      comp.write(0x08, function(err){});

      // comp.write('0x00', function(err){});
      // comp.write('0x00', function(err){});
      // comp.write('0x0A', function(err){});
     },300);
  });

})


/*

com.open(function(error){
	if(error){
	  console.log('bin voilla');
	} else {
	         console.log('port ouver');
	         com.write('h');

	var st = fs.createWriteStream('/dev/ttyACM0');
        st.write('h');
	setTimeout(function(){
	  st.write('3');
	  setTimeout(function(){
	    var buffer = new Buffer(5);
	    st.write('0x080x200x000x000x0A\n');
	    st.end();},300);
	},100);
*/
});

module.exports = router;
