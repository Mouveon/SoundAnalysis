
$(function() {
  $('#stop').click(function(){
    console.log("Stop mesure");

    var data = {};
 
    data.st = 0;

    console.log(data);
    $.ajax({
      type: 'POST',
      data: JSON.stringify(data),
      contentType: 'application/json',
      url: window.location.href+'/acquisition',
      success: function(data) {
      console.log('bravo: '+JSON.stringify(data));
      console.log(data);
      },
      error: function(xhr, status, error) {
        console.log('ERRUER'+error.message);
      },
    });
  });

  $('#start').click(function(){
    $('#start').prop("disabled",true);
    $('#stop').prop("disabled",true);
    console.log("Démarrage mesure");


    setTimeout(function(){
      console.log("On desactive");
      $('#start').removeAttr("disabled");
      $('#stop').removeAttr("disabled");
    },4000);  

    var data = {};
 
    var Idgr= String($.now());
    var sono = $.trim($('#sonom').text());
    var mic =$.trim($('#mic').text());
    console.log('Id unique: '+Idgr);   
    console.log('Sono: '+sono);   
    console.log('Mic: '+mic);   

    data.st = 1;
    data.Idgr=Idgr;
    data.sono=sono;
    data.mic=mic;

    console.log(data);
    $.ajax({
      type: 'POST',
      data: JSON.stringify(data),
      contentType: 'application/json',
      url: window.location.href+'/acquisition',
      success: function(data) {
      console.log('bravo: '+JSON.stringify(data));
      console.log(data);
      $('#Idgr').empty().append("<dl> <dt>Session d'enregistrement: </dt> <dd>"+Idgr+"</dd></dl>");
      },
      error: function(xhr, status, error) {
        console.log('ERRUER'+error.message);
      },
    });
  });

  $('#envoi').click(function(){
    console.log("Envoi detect");
    
    var data = {};
 
    data.commande = $('#commande').val();
    console.log(data);
    $.ajax({
      type: 'POST',
      data: JSON.stringify(data),
      contentType: 'application/json',
      url: window.location.href+'/com',
      success: function(data) {
      console.log('bravo: '+JSON.stringify(data));
      $('#reponse').val(data);
      },
      error: function(xhr, status, error) {
        console.log('ERRUER'+error.message);
      },
    });
  });
});
