
//beaucoup trp de legacy code
//A clean
//Sert seulement pour la page audio

$(function() {
  $('#barre').val('1');
  $('#volDB').val('4.0');
  

  $('#barre').on('input', function() {
    var chagt = 0.64*parseFloat($(this).val())*100-60;

    console.log(chagt);
    console.log(0.64*parseFloat($(this).val())*100-60);
    $('#volDB').val(((0.64*parseFloat($(this).val()))*100-60).toFixed(1));
    if($(this).val() != '0'){
      $('#vol').children().removeClass('glyphicon-volume-off');
      $('#vol').children().addClass('glyphicon-volume-up');    
    }
    else{
      $('#vol').children().removeClass('glyphicon-volume-up');
      $('#vol').children().addClass('glyphicon-volume-off');
    }
  });

/* Tentative de correction des textes affiché (c'est un peu inutile)
  var arr = [];

  $('#liste_d option').each(function() {
   arr.push($(this).text());
  });

  $('#liste_d option').each(function(){
    $(this).text(
	$(this).text().substr(0,
	    $(this).text().lastIndexOf("(hw:")
	)
    );
  });

  console.log(arr);
*/
  var tempo= $('#tmp').text();
  var periph = [];
  var joue = 0;
  var repete = 0;
  var saveVol = 0;
//  var tmp = $("#liste_d option:selected").text();
//  var sortie = tmp.substring(tmp.lastIndexOf("hw:")+3,tmp.lastIndexOf("hw:")+6);
/*
    var sortie =  $("#liste_d option:selected").text()[0]
		  +$("#liste_d option:selected").text()[1]
		  +","
		  +$("#liste_d option:selected").text()[3]
		  +$("#liste_d option:selected").text()[4];
    console.log('hw:'+sortie);
*/

    console.log(tempo);
/*
    periph.push(0);

    for(var z=0;z<tempo.length;z++){ 
      if(tempo[z] == ','){
        periph.push(z+2);
      }
    }
*/

periph = tempo.split(",");
console.log(periph);
//VERIFICATION
    for(var o=0; o<periph.length; o++){
      console.log(periph[o]);
      if(periph[o][1] == $("#liste_d option:selected").text()[1]){
	console.log("Ah!");
        $('#liste_a').append($('<option>',{
	  text: periph[o]
	}));    
      }
    }


  console.log(periph);


//  console.log(tmp.lastIndexOf("hw:")+3);
//  console.log(tmp.lastIndexOf("hw:")+5);
//  console.log(sortie);

//Y'a du legacy code ici, beaucoup (changement de décision)
//gardé le code teste/valide

  $("#volDB").change(function(){
  
    var op = ((parseFloat($(this).val())+60)/0.64)/100;
  //  op = op/0.64;
   // op = op/100;
    console.log(op);
    $('#barre').val(op);   
   // console.log(($(this).val()+60)/(0.64));   


    var data = {};

    data.volume = $(this).val();
    data.type = "DB";

    $.ajax({
      type: 'POST',
      data: JSON.stringify(data),
      contentType: 'application/json',
      url: window.location.href+'/test',
      success: function(data) {
	console.log('bravo');
	console.log(JSON.stringify(data));
      },
      error: function(xhr, status, error) {
        console.log('ERRUER'+error.message);
      },
    });
  });

  $('#liste_d').change(function(){
    /*
4      sortie =	  $("#liste_d option:selected").text()[0]
		  +$("#liste_d option:selected").text()[1]
		  +","
		  +$("#liste_d option:selected").text()[3]
		  +$("#liste_d option:selected").text()[4];


    console.log(sortie);
    */
  


    $('#liste_a').children().remove();


    for(var o=0; o<periph.length; o++){
      console.log(periph[o]);
      if(periph[o][1] == $("#liste_d option:selected").text()[1]){
	console.log("Ah!");
        $('#liste_a').append($('<option>',{
	  text: periph[o]
	}));    
      }
    }
  });


  $('.repete').mouseenter(function(){
    $("#aide").css({"display":"inherit","position": "absolute", "padding": "2px", "z-index": "99", "left": "200px", "top": "20px", "border-radius": "10px"});
    $("#aide").text("Délais en sec.");
  });

  $('.repete').mouseleave(function(){
    $("#aide").css("display","none");
    $("#aide").text("");
  });


  $('.repete2').mouseenter(function(){
    $("#aide").css({"display":"inherit","position": "absolute", "padding": "2px", "z-index": "99", "left": "150px", "top": "100px", "border-radius": "10px"});
    $("#aide").text("Volume");
  });

  $('.repete2').mouseleave(function(){
    $("#aide").css("display","none");
    $("#aide").text("");
  });

    $('.classic').click(function(){
    console.log("qqch");
    $(this).toggleClass('active');
    $(this).trigger('changementLect');
  });

  $('#play').on('changementLect',function(e){
    if ($(this).hasClass("active")){
      $('#stop').removeClass('active');	
      $('#play').children().removeClass('glyphicon-play');
      $('#play').children().addClass('glyphicon-stop');
    }
    else {
      $('#play').children().removeClass('glyphicon-stop');
      $('#play').children().addClass('glyphicon-play');
    }

  });

  $('#stop').on('changementLect',function(e){
    if ($(this).hasClass("active")){
      $('#play').removeClass('active');
    }
  });

  $('#vol').click(function(){
    console.log("Vol detect");
    console.log($('#vol').children());
	//MUTE
    if($('#barre').val() != '0'){
      saveVol = $('#barre').val();
      console.log(saveVol);

      $('#barre').val(0);
      $('#volDB').val('0');
      $('#vol').children().removeClass('glyphicon-volume-up');
      $('#vol').children().addClass('glyphicon-volume-off');
      var data = {};
 
      data.mute = 1;

      $.ajax({
        type: 'POST',
        data: JSON.stringify(data),
        contentType: 'application/json',
        url: window.location.href+'/test',
        success: function(data) {
  	  console.log('bravo');
	  console.log(JSON.stringify(data));
        },
        error: function(xhr, status, error) {
        console.log('ERRUER'+error.message);
        },
      });
    }
	//UNMUTE
    else{
      $('#barre').val(saveVol);
      $('#volDB').val((0.64*parseFloat(saveVol)*100-60).toFixed(1));

      $('#vol').children().removeClass('glyphicon-volume-off');
      $('#vol').children().addClass('glyphicon-volume-up');

      var data = {};
 
      data.mute = 2;

      $.ajax({
        type: 'POST',
        data: JSON.stringify(data),
        contentType: 'application/json',
        url: window.location.href+'/test',
        success: function(data) {
  	  console.log('bravo');
	  console.log(JSON.stringify(data));
        },
        error: function(xhr, status, error) {
        console.log('ERRUER'+error.message);
        },
      });
    }
  });

  $(document).on('change','#barre', function(){
    var chagt = 0.64*parseFloat($(this).val())*100-60;

/*
    console.log(chagt);
    console.log(0.64*parseFloat($(this).val())*100-60);
    $('#volDB').val((0.64*parseFloat($(this).val()))*100-60);
    if($(this).val() != '0'){
      $('#vol').children().removeClass('glyphicon-volume-off');
      $('#vol').children().addClass('glyphicon-volume-up');    
    }
    else{
      $('#vol').children().removeClass('glyphicon-volume-up');
      $('#vol').children().addClass('glyphicon-volume-off');
    }
*/
    var data = {};

    data.volume = chagt;

    $.ajax({
      type: 'POST',
      data: JSON.stringify(data),
      contentType: 'application/json',
      url: window.location.href+'/test',
      success: function(data) {
	console.log('bravo');
	console.log(JSON.stringify(data));
      },
      error: function(xhr, status, error) {
        console.log('ERRUER'+error.message);
      },
    });
  });

  $('#play').click(function(){
    console.log("ptet");

    $("button[id^='son']").attr("disabled", true);

    setTimeout(function() {
      console.log("on desactive");
      $("button[id^='son']").removeAttr("disabled"); 
    },300);

    if(joue == 0) {
      $('#enCours').text($('#son').val());
	//C'est un play
      joue =1;
    }
    else if (joue == 1) {
      $('#enCours').text("En attente de lecture");
	//C'est un stop
      joue = 0;
    }

    console.log("joue"+joue);

    var sortie = $("#liste_d option:selected").text()[0]+$("#liste_d option:selected").text()[1];
    console.log("IKIK"+sortie);
    console.log(sortie);

    var data = {};
    //data.

    if($('#barre').val() == '0'){
    data.mute = 3;
    }
    data.joue = joue;
    data.repete = repete;
    if (repete == 1) data.temps = $('#delais').val();
    data.son = $('#son').val();
    data.audio = "hw:"+sortie;

    console.log(data);
    console.log(window.location.href);

    $.ajax({
      type: 'POST',
      data: JSON.stringify(data),
      contentType: 'application/json',
      url: window.location.href+'/test',
      success: function(data) {
	console.log("bravo "+JSON.stringify(data));
	//Test si le serveur renvoit un play
	//Tant que le flag est actif on va le chercher toutes le sec.
	//Recuperation du flag
	//Fin: bouton play plus actif
      },
      error: function(xhr, status, error) {
        console.log('ERRUER'+error.message);
      },
    });
  });

  $(window).unload(function() {

    var data = {};
    //data.

    data.joue = 0;
  
    $.ajax({
      type: 'POST',
      data: JSON.stringify(data),
      contentType: 'application/json',
      url: window.location.href+'/test',
      success: function(data) {
	console.log('bravo');
	console.log(JSON.stringify(data));
      },
      error: function(xhr, status, error) {
        console.log('ERRUER'+error.message);
      },
    });
  });


  $('#repeter').click(function(){
    if(repete == 0) repete = 1;
    else repete = 0;
  
    console.log(repete);
  });

  console.log("kek");

  $("button[id^='son']").click(function(){
    $('#son').val($("#nom"+this.id.replace('son','')).text());
    if ($('#play').hasClass("active")){
     $('#play').removeClass("active");
     $('#play').children().removeClass("glyphicon-play");
     $('#play').children().addClass("glyphicon-stop");
     joue=0;
    }
      $('#play').trigger("click");
  });

  $("button[id^='del']").click(function(){

    var sonDel=  $("#nom"+this.id.replace('del','')).text();


    var r = confirm('Suppression de '+sonDel);

    if(r==true){
      var data = {};


      //Recuperer son

      data.fichier = sonDel;
  
      $.ajax({
        type: 'POST',
        data: JSON.stringify(data),
        contentType: 'application/json',
        url: window.location.href+'/supprimer',
        success: function(data) {
	  console.log('Suppression fichier');
	  location.reload();
	  //console.log(JSON.stringify(data));
        },
        error: function(xhr, status, error) {
          console.log('ERRUER'+error.message);
        },
      });
  //Envoyer serveur
  //Recharger page
  }
});

});

